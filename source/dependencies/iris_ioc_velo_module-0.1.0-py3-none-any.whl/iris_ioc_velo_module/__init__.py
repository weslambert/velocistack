#!/usr/bin/env python3
#
#
#  IRIS velo Source Code
#  Copyright (C) 2022 - Stephan Mikiss
#  stephan.mikiss@gmail.com
#  Created by Stephan Mikiss - 2022-08-07
#
#  License Lesser GNU GPL v3.0

__iris_module_interface = "IrisVeloInterface"